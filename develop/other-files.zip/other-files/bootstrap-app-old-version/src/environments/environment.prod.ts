export const environment = {
  production: true,
  jobPosition: 'Systems analyst',
  college: 'Technician\'s license',
  employer: 'BRQ digital solutions',
  employerWebSite:'http://www.brq.com/'
};
