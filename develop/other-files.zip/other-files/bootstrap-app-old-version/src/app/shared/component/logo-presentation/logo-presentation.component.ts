import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'bg-logo-presentation',
    templateUrl: './logo-presentation.component.html',
    styleUrls: ['./logo-presentation.component.scss']
})
export class LogoPresentationComponent {

    constructor() { }

}