import { Component } from "@angular/core";

@Component({
    templateUrl: './lab.component.html'
})
  
export class LabComponent {}  