import { Component } from "@angular/core";

@Component({
    templateUrl: './recommendations.component.html'
})
  
export class RecommendationsComponent {}  