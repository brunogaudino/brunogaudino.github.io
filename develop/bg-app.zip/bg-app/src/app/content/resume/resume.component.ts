import { Component } from "@angular/core";

@Component({
    templateUrl: './resume.component.html',
    styleUrls: ['./resume.component.css']
})
  
export class ResumeComponent {}