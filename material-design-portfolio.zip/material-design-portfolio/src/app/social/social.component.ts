import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bg-social',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.css']
})
export class SocialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
