import { NgModule } from '@angular/core';

import { HomeModule } from './home/home.module';

@NgModule({
  imports: [
    HomeModule
  ],
  declarations: []
})
export class ContentModule { }