import { Component } from '@angular/core';

@Component({
    selector: 'bg-social',
    templateUrl: './social.component.html',
    styleUrls: ['./social.component.css']
})

export class SocialComponent { }