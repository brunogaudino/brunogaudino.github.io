import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './content/home/home.component';
import { RecommendationsComponent } from './content/recommendations/recommendations.component';

const routes: Routes = [
    {
        path: '',
        component: HomeComponent
    },
    {
        path: 'recommendations', 
        component: RecommendationsComponent 
    },
    {
        path: '**', 
        component: HomeComponent
    }
];
//https://angular.io/guide/router#appendix-locationstrategy-and-browser-url-styles
//https://github.com/ritwickdey/ritwickdey.github.io/tree/development/src/app
@NgModule({
    imports: [
        RouterModule.forRoot(
            routes,
            { enableTracing: false }
            
        )
    ],
    exports: [ RouterModule ]
})
export class AppRoutingModule { }