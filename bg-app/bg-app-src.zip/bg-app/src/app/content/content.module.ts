import { NgModule } from "@angular/core";

import { HomeModule } from './home/home.module';
import { RecommendationsModule } from './recommendations/recommendations.module';

@NgModule({
    imports:[
        HomeModule,
        RecommendationsModule
    ]
})

export class ContentModule {}