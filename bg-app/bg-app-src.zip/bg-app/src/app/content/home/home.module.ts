import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { HomeComponent } from './home.component';
import { SocialModule } from '../../social/social.module';
import { MenuModule } from '../../menu/menu.module';
import { FooterModule } from '../../footer/footer.module';

@NgModule({
    declarations: [ 
        HomeComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        SocialModule,
        MenuModule,
        FooterModule
    ],
    exports: [
        HomeComponent
    ]
})
export class HomeModule {}