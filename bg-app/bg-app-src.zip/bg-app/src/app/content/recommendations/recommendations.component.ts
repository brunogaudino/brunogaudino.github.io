import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'bg-recommendations',
    templateUrl: './recommendations.component.html',
    styleUrls: ['./recommendations.component.css']
})

export class RecommendationsComponent{}