import { NgModule } from "@angular/core";

import { RecommendationsComponent } from "./recommendations.component";
import { SocialModule } from '../../social/social.module';
import { FooterModule } from '../../footer/footer.module';
import { MenuModule } from '../../menu/menu.module';

@NgModule({
    declarations: [
        RecommendationsComponent
    ],
    imports: [
        SocialModule,
        FooterModule,
        MenuModule
    ],
    exports: [
        RecommendationsComponent
    ]
})

export class RecommendationsModule {}